package com.grocery.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.grocery.entities.Grocery;
import com.grocery.service.GroceryService;

@RestController
public class GroceryController {
	
	@Autowired
	GroceryService service;
	
	@GetMapping("/ping")
	public String hello() {
		return "PING";
	}
	
	@GetMapping("/products")
	public List<Grocery> findAll() {
		return service.findAllProducts();
	}

	@GetMapping("/products/{id}")
	public Optional<Grocery> findById(@PathVariable int id) {
		return service.FindById(id);
	}
	
	@PostMapping("/products")
	public void save(@RequestBody Grocery product) {
		service.save(product);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/products/{id}")
	public void updateProduct(@RequestBody Grocery products,@PathVariable int id) {
		service.update(products,id);
	}
	
	
	@RequestMapping(method=RequestMethod.DELETE,value="products/{id}")
	public void deleteProduct(@PathVariable int id) {
		service.delete(id);
	}
	
	
	
	
	
	
}
