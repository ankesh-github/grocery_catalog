package com.grocery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grocery.entities.Grocery;
import com.grocery.repository.GroceryRepository;

@Service
public class GroceryService {
	
	@Autowired
	GroceryRepository repo;
	
	public List<Grocery>findAllProducts() {
		return repo.findAll();
	}
	
	public Optional<Grocery> FindById(int id) {
		return repo.findById(id);
	}
	
	
	public void save(Grocery product) {
		repo.save(product);
	}
	
	
	

	public void update(Grocery products, int id) {
		
		Optional<Grocery> optional=repo.findById(id);
		Grocery product=optional.get();
	
		product.setName(products.getName());
		product.setDescription(products.getDescription());
		product.setPrice(products.getPrice());
		repo.save(product);
		return;
		
		
		
	}

	public void delete(int id) {
		repo.deleteById(id);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
