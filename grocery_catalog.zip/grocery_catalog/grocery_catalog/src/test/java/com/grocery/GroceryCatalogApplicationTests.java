package com.grocery;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
